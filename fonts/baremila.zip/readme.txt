This is font free for PERSONAL USE

If you need for commercial use, you can buy the license here :
https://fontbundles.net/dav-studio/1113457-baremila-aesthetic-handwritten-font/rel=hllbkZ
or
https://www.creativefabrica.com/product/baremila/ref/235908/

If you have any question , feel free to drop me a message at dimasajivirgiawan@gmail.com
Follow my Instagram for more updates @davstudio_